<div class="footer">

	<div class="copyright">

		<div class="container">

			<div class="row">

				<div class="col-md-12">

					<span>jacataloguei! <br class="visible-xs visible-sm"/><?php echo date('Y'); ?> - TODOS OS DIREITOS RESERVADOS</span>

				</div>

			</div>

		</div>

	</div>

</div>