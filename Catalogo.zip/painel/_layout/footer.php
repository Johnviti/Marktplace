	
		<script src="<?php just_url(); ?>/_core/_cdn/jquery/js/jquery.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/sidebar/js/jquery.sidebar.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/sidr/js/jquery.sidr.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/maskMoney/js/maskmoney.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/maskedInput/js/jquery.maskedinput.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/validate/js/jquery.validate.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/avatarPreview/js/jquery.uploadPreview.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/autocomplete/js/autocomplete.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/spectrum/js/spectrum.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/steps/js/jquery.steps.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/multiUpload/js/image-uploader.min.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/panel/js/template.js"></script>
		<script src="<?php just_url(); ?>/_core/_cdn/clipboard/clipboard.js"></script>
		<?php system_footer(); ?>

	</body>

</html>