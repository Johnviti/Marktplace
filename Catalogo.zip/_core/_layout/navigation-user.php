<nav class="navbar">
	<ul class="nav navbar-nav pushnav">
		<li><a class="nobordertop" href="<?php just_url(); ?>/login"><i class="lni lni-user icon-left"></i> Login</a></li>
		<li><a href="<?php just_url(); ?>/comece"><i class="lni lni-plus icon-left"></i> Cadastro</a></li>
		<li><a target="_blank" href="https://wa.me?text=Venha conhecer! <?php just_url(); ?>"><i class="lni lni-whatsapp icon-left"></i> Indique</a></li>
	</ul>
</nav> 

<div class="clear"></div>