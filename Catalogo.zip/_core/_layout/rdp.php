<div class="footer">

	<div class="copyright">

		<div class="container">

			<div class="row">

				<div class="col-md-12">

					<span>jacataloguei <?php echo date('Y'); ?>
					<br class="visible-xs visible-sm"/>
					!</span>

				</div>

			</div>

		</div>

	</div>

</div>