<nav class="navbar">
	<ul class="nav navbar-nav">
		<li><a href="<?php admin_url(); ?>/configuracoes"><i class="lni lni-cog icon-left"></i> Configurações</a></li>
		<li><a href="<?php echo $app['url']; ?>/logout"><i class="lni lni-power-switch icon-left"></i> Sair</a></li>
	</ul>
</nav> 

<div class="clear"></div>