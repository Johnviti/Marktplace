		</div>

		<script src="<?php echo $app['url']; ?>/_core/_cdn/sidebar/js/jquery.sidebar.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/sidr/js/jquery.sidr.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/maskMoney/js/maskmoney.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/maskedInput/js/jquery.maskedinput.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/validate/js/jquery.validate.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/sticky/js/jquery.sticky.min.js"></script>
		<script src="<?php echo $app['url']; ?>/_core/_cdn/app/js/template.js"></script>
		<?php system_footer(); ?>

	</body>

</html>