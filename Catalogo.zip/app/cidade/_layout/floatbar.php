<div class="floatbar-holder"></div>

<div class="floatbar">

	<div class="floatitem">
		<span class="floaticon" href=""><i class="lni lni-frame-expand" onclick="telacheia();"></i></span>
	</div>
	<div class="floatitem">
		<span id="addtohome" class="floaticon" href=""><i class="lni lni-star"></i></span>
	</div>
	<div class="floatitem">
		<span class="floaticon" href=""><i class="lni lni-bullhorn"></i></span>
	</div>

</div>