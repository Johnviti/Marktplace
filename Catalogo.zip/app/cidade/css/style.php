<?php
header("Content-type: text/css");
include('../../../_core/_includes/config.php');
$cor = "rgba(4,170,96,1)";
?>

/* ALL MOBILE */

@media (max-width: 991px) {

.header .top,
.sidebar-header,
.footer-info {
background: #181439;
}

.user-menu i,
.holder-shop-bag i {
color: #fff;
}

}

/* ALL DESK */

@media (min-width: 991px) {

}