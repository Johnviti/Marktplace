<div id="modalalerta" class="modal fade" role="dialog">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        
      </div>

    </div>

  </div>

</div>

<div id="modalcarrinho" class="modal fade" role="dialog">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><i class="lni lni-close"></i></button>
      </div>

      <div class="modal-body">
        
      </div>

    </div>

  </div>

</div>